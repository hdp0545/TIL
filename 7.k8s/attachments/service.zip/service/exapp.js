var http = require('http');
var os = require('os');
const host = "myhost.ibm.com";
const port = 8000;

http.createServer( (req, res) => {
  console.log('requested: ' + req.url);
  res.writeHead(200, {'Content-Type':'text/plain'});
  res.write('This is EXTERNAL service');
  res.end();
}).listen(port, () => {
  console.log('Listen ...' + host+':'+port);
});
