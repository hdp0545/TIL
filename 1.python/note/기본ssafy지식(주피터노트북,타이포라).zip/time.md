시간 재는 code

```python
import time
#stime은 time.time()은 현재의 타임을 알려줌.
stime = time.time()


print(time.time()-stime)
```

